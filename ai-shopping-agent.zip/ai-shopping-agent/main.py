import json
import os
import re
import sqlite3
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import requests
from duckduckgo_search import DDGS
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None
    types = None

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DB_PATH = BASE_DIR / "shopping_agent.db"
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


@contextmanager
def connect_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_db() -> None:
    with connect_db() as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS search_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_query TEXT NOT NULL,
            recommendation_summary TEXT NOT NULL,
            products_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")


@asynccontextmanager
async def lifespan(_: FastAPI):
    initialize_db()
    yield


app = FastAPI(title="AI Shopping Agent", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=500)


def _extract_price(text: str) -> int | None:
    patterns = [
        r"(?:\u20b9|INR\s*|Rs\.?\s*)\s*([\d,]+)",
        r"([\d,]+)\s*(?:INR|rupees?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                price = int(match.group(1).replace(",", ""))
                if 1 <= price <= 20_000_000:
                    return price
            except ValueError:
                continue
    return None


class _DuckDuckGoHTMLParser(HTMLParser):
    """Read result titles, snippets, and outbound URLs from DDG's HTML results."""

    def __init__(self) -> None:
        super().__init__()
        self.results: list[dict[str, str]] = []
        self.capture: str | None = None
        self.current: dict[str, str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr = dict(attrs)
        classes = (attr.get("class") or "").split()
        if tag == "a" and "result__a" in classes:
            href = attr.get("href") or ""
            parsed = urlparse(href if href.startswith("http") else f"https:{href}")
            destination = parse_qs(parsed.query).get("uddg", [href])[0]
            self.current = {"title": "", "body": "", "href": unquote(destination)}
            self.results.append(self.current)
            self.capture = "title"
        elif "result__snippet" in classes and self.results:
            self.current = self.results[-1]
            self.capture = "body"

    def handle_endtag(self, tag: str) -> None:
        if tag in {"a", "div", "td"}:
            self.capture = None
            self.current = None

    def handle_data(self, data: str) -> None:
        if self.capture and self.current is not None:
            self.current[self.capture] += data


def _search_duckduckgo_html(query: str) -> list[dict[str, str]]:
    response = requests.post(
        "https://html.duckduckgo.com/html/",
        data={"q": query},
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36"},
        timeout=15,
    )
    response.raise_for_status()
    parser = _DuckDuckGoHTMLParser()
    parser.feed(response.text)
    return parser.results[:5]


def search_products(query: str) -> list[dict[str, Any]]:
    """Prefer live DDG results; use category and budget matched product references if search is empty."""
    results = []
    try:
        with DDGS() as search_client:
            results = search_client.text(query, max_results=5)
    except Exception as ddgs_error:
        print(f"DDGS search failed; trying the HTML endpoint: {ddgs_error}")

    if not results:
        try:
            results = _search_duckduckgo_html(query)
        except Exception as html_error:
            print(f"DuckDuckGo HTML search failed: {html_error}")

    products = []
    for item in results or []:
        title = str(item.get("title") or "").strip()
        description = str(item.get("body") or "").strip()
        url = str(item.get("href") or "").strip()
        if not title or not url:
            continue
        products.append({
            "title": title[:240],
            "price": _extract_price(f"{title} {description}"),
            "specs": description[:500] or "Specifications were not included in the search snippet.",
            "source_link": url,
            "why_recommended": description[:500] or "This live result matched your search.",
            "source_type": "live_search",
        })
    if products:
        return products[:5]

    intent = parse_intent(query)
    return _fallback_catalog_products(intent)


SYSTEM_INSTRUCTION = (
    "You are a strict shopping agent. Never invent products or display cached fallback laptops/mice. "
    "Only generate product cards based strictly on the query and live search tool output. "
    "Return only items matching the exact product category requested by the user."
)


CATEGORY_SYNONYMS = {
    "watch": ("watch", "watches", "smartwatch", "smart watch", "wristwatch"),
    "earbuds": ("earbud", "earbuds", "earphone", "earphones", "tws", "in-ear"),
    "headphones": ("headphone", "headphones", "headset", "headsets", "over-ear"),
    "laptop": ("laptop", "laptops", "notebook", "notebooks"),
    "phone": ("phone", "phones", "smartphone", "smartphones", "mobile phone"),
    "tablet": ("tablet", "tablets", "ipad"),
    "camera": ("camera", "cameras", "dslr", "mirrorless"),
    "speaker": ("speaker", "speakers", "soundbar", "soundbars"),
}

# Reference listings verified against Indian brand/store pages on 2026-09-30.
# They are used only when both DuckDuckGo interfaces return no listings.
FALLBACK_CATALOG = {
    "watch": [
        {"title": "boAt Wave Call 3", "price": 1399, "specs": "Smartwatch · 1.83-inch HD display · Bluetooth calling · health tracking", "source_link": "https://www.boat-lifestyle.com/products/wave-call-3-bluetooth-calling-smartwatch", "price_source_link": "https://www.boat-lifestyle.com/products/wave-call-3-bluetooth-calling-smartwatch", "status_note": "Brand page showed restocking soon."},
        {"title": "Noise ColorFit Pulse 2", "price": 1199, "specs": "Smartwatch · 1.8-inch display · 50 sports modes · 100+ watch faces · IP68", "source_link": "https://www.gonoise.com/products/noise-colorfit-pulse-2-smartwatch", "price_source_link": "https://www.gadgets360.com/noise-colorfit-pulse-2-price-in-india-111140", "status_note": "Price reference from a current Indian price listing."},
        {"title": "Fire-Boltt Ninja Phantom", "price": 1199, "specs": "Smartwatch · 2.01-inch HD display · Bluetooth calling · metal finish", "source_link": "https://www.fireboltt.com/collections/ninja-series-1", "price_source_link": "https://www.fireboltt.com/collections/ninja-series-1", "status_note": "Brand collection showed this model out of stock when checked."},
    ],
    "earbuds": [
        {"title": "boAt Airdopes 141", "price": 999, "specs": "Wireless earbuds · up to 42 hours playback · ENx technology · BEAST mode", "source_link": "https://www.boat-lifestyle.com/products/airdopes-141", "price_source_link": "https://www.boat-lifestyle.com/products/airdopes-141", "status_note": "Brand listing price; availability may vary."},
        {"title": "Noise Buds VS102+", "price": 1424, "specs": "True wireless earbuds · up to 70 hours playtime · quad mic · ANC", "source_link": "https://www.gonoise.com/products/noise-buds-vs102-plus", "price_source_link": "https://www.gonoise.com/products/noise-buds-vs102-plus", "status_note": "Brand listing offer price; availability may vary."},
        {"title": "Noise Buds Venus", "price": 1899, "specs": "True wireless earbuds · ANC · up to 40 hours playtime", "source_link": "https://www.gonoise.com/products/noise-buds-venus-truly-wireless-earbuds", "price_source_link": "https://www.gonoise.com/products/noise-buds-venus-truly-wireless-earbuds", "status_note": "Brand listing price; availability may vary."},
    ],
    "laptop": [
        {"title": "ASUS Vivobook Go 14 (Ryzen 3 7320U)", "price": 30990, "specs": "Laptop · Ryzen 3 7320U · 8GB RAM · 512GB SSD · 14-inch", "source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "price_source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "status_note": "ASUS India eShop listed this configuration at this price."},
        {"title": "ASUS Vivobook Go 15 (Intel Core i3)", "price": 33990, "specs": "Laptop · 12th Gen Intel Core i3 · 8GB RAM · 512GB SSD · 15.6-inch", "source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "price_source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "status_note": "ASUS India eShop listed this configuration at this price."},
        {"title": "ASUS Vivobook Go 15 OLED (Ryzen 5 7520U)", "price": 46990, "specs": "Laptop · Ryzen 5 7520U · 16GB RAM · 512GB SSD · OLED", "source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "price_source_link": "https://www.asus.com/in/content/eshop-everyday-laptops/", "status_note": "ASUS India eShop listed this configuration at this price."},
    ],
    "phone": [
        {"title": "moto g37", "price": 18999, "specs": "Smartphone · 4GB RAM · 64GB storage · 5G", "source_link": "https://www.motorola.in/smartphones/d", "price_source_link": "https://www.motorola.in/smartphones/d", "status_note": "Motorola India store listing price."},
        {"title": "moto g37 power", "price": 19999, "specs": "Smartphone · 4GB RAM · 64GB storage · long-battery model", "source_link": "https://www.motorola.in/smartphones/d", "price_source_link": "https://www.motorola.in/smartphones/d", "status_note": "Motorola India store listing price."},
        {"title": "motorola edge 70 fusion", "price": 30999, "specs": "Smartphone · 8GB RAM · 128GB storage · 5G", "source_link": "https://www.motorola.in/smartphones/d", "price_source_link": "https://www.motorola.in/smartphones/d", "status_note": "Motorola India store listing price."},
    ],
}


def parse_intent(query: str) -> dict[str, Any]:
    normalized = query.lower()
    category = next((name for name, variants in CATEGORY_SYNONYMS.items()
                     if any(re.search(rf"\b{re.escape(variant)}\b", normalized) for variant in variants)), None)
    budget_match = re.search(
        r"(?:under|below|less than|up to|max(?:imum)?|budget(?: of)?)\s*(?:\u20b9|rs\.?|inr)?\s*([\d,]+(?:\.\d+)?)\s*(k|l|lakh)?",
        normalized,
    )
    if not budget_match:
        budget_match = re.search(r"(?:\u20b9|rs\.?|inr)\s*([\d,]+(?:\.\d+)?)\s*(k|l|lakh)?", normalized)
    budget = None
    if budget_match:
        amount = float(budget_match.group(1).replace(",", ""))
        scale = (budget_match.group(2) or "").lower()
        budget = int(amount * (100_000 if scale in {"l", "lakh"} else 1_000 if scale == "k" else 1))
    remove = {"a", "an", "the", "for", "with", "under", "below", "less", "than", "up", "to", "max", "maximum", "budget", "of", "in", "and", "or", "buy", "best", "good", "please"}
    remove.update(word for variants in CATEGORY_SYNONYMS.values() for variant in variants for word in variant.split())
    features = [word for word in re.findall(r"[a-z0-9]+", normalized) if word not in remove and not word.isdigit()]
    return {"query": query, "category": category, "budget_inr": budget, "key_features": features}


def _fallback_catalog_products(intent: dict[str, Any]) -> list[dict[str, Any]]:
    """Return verified category-specific reference products that fit the parsed budget."""
    category = intent.get("category")
    candidates = FALLBACK_CATALOG.get(category, [])
    budget = intent.get("budget_inr")
    selected = [product for product in candidates if budget is None or product["price"] <= budget]
    formatted = []
    for product in selected[:3]:
        item = dict(product)
        item["source_type"] = "verified_catalog_fallback"
        status_note = item.pop("status_note")
        item["why_recommended"] = f"Verified category and budget reference. Price and stock can change; check the linked listing. {status_note}"
        formatted.append(item)
    return formatted


def filter_matching_products(intent: dict[str, Any], products: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    synonyms = CATEGORY_SYNONYMS.get(intent.get("category"), ())
    matching: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    budget = intent.get("budget_inr")
    for product in products:
        searchable = f"{product.get('title', '')} {product.get('specs', '')}".lower()
        category_ok = not synonyms or any(term in searchable for term in synonyms)
        price = product.get("price")
        budget_ok = budget is None or price is None or price <= budget
        if category_ok and budget_ok:
            matching.append(product)
        else:
            excluded.append({"title": product.get("title"), "reason": "category mismatch" if not category_ok else "over budget"})
    return matching, excluded


def _search_with_agent_tool(query: str) -> list[dict[str, Any]]:
    """Make Gemini request the live search function before any synthesis."""
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key or genai is None or types is None:
        return search_products(query)

    try:
        client = genai.Client(api_key=api_key)
        declaration = types.FunctionDeclaration(
            name="search_products",
            description="Search DuckDuckGo live for products matching the shopper's request. Return only current external web results.",
            parameters={
                "type": "OBJECT",
                "properties": {"query": {"type": "STRING", "description": "The shopper's exact product request"}},
                "required": ["query"],
            },
        )
        tool = types.Tool(function_declarations=[declaration])
        contents: list[Any] = [types.Content(role="user", parts=[types.Part.from_text(text=(
            "Call search_products before producing any recommendation. Use the shopper's query as the tool query. "
            "Do not produce product cards in this first step.\n\n"
            f"Shopper query: {query}"
        ))])]
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                tools=[tool],
                tool_config=types.ToolConfig(function_calling_config=types.FunctionCallingConfig(
                    mode="ANY", allowed_function_names=["search_products"]
                )),
                temperature=0.1,
            ),
        )
        calls = [part.function_call for candidate in (response.candidates or [])
                 for part in (candidate.content.parts or []) if part.function_call]
        search_call = next((call for call in calls if call.name == "search_products"), None)
        if search_call is None:
            return search_products(query)
        # Always search the exact original query, regardless of model-supplied arguments.
        products = search_products(query)
        contents.append(response.candidates[0].content)
        contents.append(types.Content(role="user", parts=[types.Part.from_function_response(
            name="search_products",
            response={"products": products},
        )]))
        # Complete the function-call turn with the actual tool output; product cards
        # are still filtered and constructed from the original live result objects.
        client.models.generate_content(
            model=GEMINI_MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION + " Do not recommend yet; acknowledge only whether live results were returned.",
                temperature=0.0,
            ),
        )
        return products
    except Exception as exc:
        print(f"Gemini search tool unavailable; using direct live search: {exc}")
        return search_products(query)


def summarize_matches(query: str, intent: dict[str, Any], products: list[dict[str, Any]]) -> str:
    if not products:
        return f'No live results matched "{query}". Try changing the product type, budget, or features.'
    if all(product.get("source_type") == "verified_catalog_fallback" for product in products):
        return f'Live search was unavailable. Showing {len(products)} verified reference picks for "{query}" that fit the parsed category and budget. Check seller pages for current price and stock.'
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key or genai is None or types is None:
        return f'{len(products)} live result(s) match "{query}".'
    try:
        response = genai.Client(api_key=api_key).models.generate_content(
            model=GEMINI_MODEL,
            contents=(
                f"Current user query: {query}\nParsed intent: {json.dumps(intent)}\n"
                f"Allowed live search results: {json.dumps(products, ensure_ascii=False)}\n"
                "Return JSON with a concise summary and a products array. Include ONLY products whose category matches the user's query. "
                "Every product must be copied from Allowed live search results; do not invent, replace, or add items."
            ),
            config=types.GenerateContentConfig(system_instruction=SYSTEM_INSTRUCTION, temperature=0.1),
        )
        if response.text:
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", response.text.strip(), flags=re.IGNORECASE)
            parsed = json.loads(text)
            return str(parsed.get("summary") or f'{len(products)} live result(s) match "{query}".')[:500]
    except Exception as exc:
        print(f"Gemini recommendation summary unavailable: {exc}")
    return f'{len(products)} live result(s) match "{query}".'


def shopping_workflow(user_query: str):
    query = user_query.strip()
    state: dict[str, Any] = {"user_query": user_query, "query": query, "intent": None, "raw_results": [], "matching_results": [], "excluded_results": [], "saved_id": None}
    yield {"kind": "step", "step": 1, "status": "running", "message": "Parsing product intent, budget, and requested features...", "state": state}
    intent = parse_intent(query)
    state["intent"] = intent
    yield {"kind": "step", "step": 1, "status": "done", "message": f"Intent parsed: category={intent['category'] or 'general'}, budget={intent['budget_inr'] or 'not specified'} INR, features={intent['key_features']}", "state": state}

    yield {"kind": "step", "step": 2, "status": "running", "message": "Calling live DuckDuckGo search and extracting URLs, snippets, and prices...", "state": state}
    raw_products = _search_with_agent_tool(query)
    state["raw_results"] = raw_products
    source_type = raw_products[0].get("source_type") if raw_products else None
    search_source = "verified category catalog" if source_type == "verified_catalog_fallback" else "live web search"
    yield {"kind": "step", "step": 2, "status": "done", "message": f"{search_source} returned {len(raw_products)} result(s).", "state": state}

    yield {"kind": "step", "step": 3, "status": "running", "message": "Comparing product category and budget against live results...", "state": state}
    products, excluded = filter_matching_products(intent, raw_products)
    if not products:
        # A non-empty but irrelevant/out-of-budget search result set is equivalent
        # to no usable live result; try only verified items for the parsed category.
        fallback_products = _fallback_catalog_products(intent)
        if fallback_products:
            products, fallback_excluded = filter_matching_products(intent, fallback_products)
            excluded.extend(fallback_excluded)
            state["fallback_results"] = fallback_products
    state["matching_results"] = products
    state["excluded_results"] = excluded
    yield {"kind": "step", "step": 3, "status": "done", "message": f"Kept {len(products)} matching result(s); filtered {len(excluded)} irrelevant or over-budget result(s).", "state": state}

    yield {"kind": "step", "step": 4, "status": "running", "message": "Preparing recommendations and saving exact query plus results to SQLite...", "state": state}
    summary = summarize_matches(query, intent, products)
    created_at = datetime.now(timezone.utc).isoformat()
    with connect_db() as connection:
        cursor = connection.execute(
            "INSERT INTO search_history (user_query, recommendation_summary, products_json, created_at) VALUES (?, ?, ?, ?)",
            (user_query, summary, json.dumps(products, ensure_ascii=False), created_at),
        )
        search_id = cursor.lastrowid
    state["saved_id"] = search_id
    result = {"id": search_id, "query": user_query, "summary": summary, "products": products, "created_at": created_at}
    yield {"kind": "step", "step": 4, "status": "done", "message": f"Saved search #{search_id} with {len(products)} result(s) to shopping_agent.db.", "state": state}
    yield {"kind": "complete", "result": result, "state": state}


@app.get("/")
def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/simulator")
def simulator_page() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.post("/api/search")
def api_search(request: SearchRequest) -> dict[str, Any]:
    if len(request.query.strip()) < 2:
        raise HTTPException(status_code=422, detail="Please enter at least two characters.")
    result = next(event["result"] for event in shopping_workflow(request.query) if event["kind"] == "complete")
    return result


@app.post("/api/simulate")
def api_simulate(request: SearchRequest) -> StreamingResponse:
    if len(request.query.strip()) < 2:
        raise HTTPException(status_code=422, detail="Please enter at least two characters.")

    def event_stream():
        for event in shopping_workflow(request.query):
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/history")
def api_history() -> list[dict[str, Any]]:
    with connect_db() as connection:
        rows = connection.execute(
            "SELECT id, user_query, recommendation_summary, products_json, created_at "
            "FROM search_history ORDER BY created_at DESC, id DESC"
        ).fetchall()
    return [{
        "id": row["id"],
        "query": row["user_query"],
        "summary": row["recommendation_summary"],
        "products": json.loads(row["products_json"]),
        "created_at": row["created_at"],
    } for row in rows]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=int(os.getenv("PORT", "8080")))
