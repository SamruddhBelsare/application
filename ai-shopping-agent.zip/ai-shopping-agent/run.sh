#!/usr/bin/env bash
set -euo pipefail

# Set GEMINI_API_KEY in your shell to enable Gemini; local search still works without it.
export GEMINI_API_KEY="${GEMINI_API_KEY:-}"
export GEMINI_MODEL="${GEMINI_MODEL:-gemini-2.5-flash}"
export PORT="${PORT:-8080}"

cd "$(dirname "$0")"
python -m uvicorn main:app --host 127.0.0.1 --port "$PORT"
