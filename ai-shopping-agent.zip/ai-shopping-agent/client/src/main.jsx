import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import './styles.css';

const API='http://localhost:3001/api';

function ProductCard({p, rank}){
  return <article className="product">
    <div className="rank">#{rank}</div>
    <div className="product-main">
      <div className="source">{p.source || 'Web result'}</div>
      <h3>{p.name}</h3>
      <p>{p.summary || 'Relevant product found from public web results.'}</p>
      <div className="chips">{Object.entries(p.specs||{}).filter(([,v])=>v).slice(0,5).map(([k,v])=><span key={k}>{k}: {v}</span>)}</div>
      <div className="card-bottom"><strong>{p.price ? `${p.currency||'₹'} ${p.price}` : 'Price on source'}</strong><a href={p.url} target="_blank">View source ↗</a></div>
    </div>
  </article>
}

function App(){
  const [query,setQuery]=useState('Find the best laptop for AI development under ₹70,000');
  const [data,setData]=useState(null); const [history,setHistory]=useState([]); const [loading,setLoading]=useState(false); const [error,setError]=useState('');
  const loadHistory=()=>fetch(API+'/history').then(r=>r.json()).then(setHistory).catch(()=>{});
  useEffect(()=>{loadHistory()},[]);
  const search=async()=>{ if(!query.trim()) return; setLoading(true);setError('');setData(null); try{const r=await fetch(API+'/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query})});const j=await r.json();if(!r.ok)throw new Error(j.error);setData(j);loadHistory()}catch(e){setError(e.message)}finally{setLoading(false)}};
  return <div className="app">
    <header><div className="brand"><div className="logo">✦</div><div><b>ShopPilot AI</b><small>Agentic shopping assistant</small></div></div><div className="status">● LIVE WEB SEARCH</div></header>
    <main>
      <section className="hero"><div className="eyebrow">AI SHOPPING AGENT</div><h1>Tell me what you want.<br/><em>I’ll compare it.</em></h1><p>Understands your requirements, searches the public web, extracts products, compares them and explains the best options.</p>
        <div className="searchbox"><textarea value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();search()}}}/><button onClick={search} disabled={loading}>{loading?'Searching…':'Find products →'}</button></div>
        <div className="examples"><span>Try:</span>{['Best laptop for AI development under ₹70,000','Best phone under ₹30,000 with great camera','Mechanical keyboard under ₹5,000'].map(x=><button key={x} onClick={()=>setQuery(x)}>{x}</button>)}</div>
      </section>
      {error&&<div className="error">⚠ {error}. Make sure the backend is running and GEMINI_API_KEY is configured.</div>}
      {loading&&<section className="workflow"><div>1 <b>Understanding</b><small>requirements & budget</small></div><div>2 <b>Searching</b><small>public web sources</small></div><div>3 <b>Extracting</b><small>products & specs</small></div><div>4 <b>Comparing</b><small>fit + value</small></div></section>}
      {data&&<section className="results">
        <div className="result-head"><div><span className="eyebrow">RESULTS</span><h2>Best matches for your request</h2></div><div className="winner">🏆 {data.comparison?.winner || 'Top match'}</div></div>
        <div className="requirements"><b>Agent understood:</b> {data.requirements?.useCase || data.query} {data.requirements?.budget && <span>Budget ₹{data.requirements.budget}</span>} {data.requirements?.mustHave?.map(x=><span key={x}>{x}</span>)}</div>
        <div className="products">{data.products.map((p,i)=><ProductCard p={p} rank={i+1}/>)}</div>
        {data.comparison?.caveats&&<div className="caveat"><b>Agent note:</b> {data.comparison.caveats}</div>}
      </section>}
      <section className="architecture"><div><span className="eyebrow">HOW IT WORKS</span><h2>One request → four tools → one decision</h2></div><div className="flow"><div><b>LLM</b><span>Requirement parser</span></div><i>→</i><div><b>WEB SEARCH</b><span>Public product discovery</span></div><i>→</i><div><b>EXTRACTOR</b><span>Normalize price/specs</span></div><i>→</i><div><b>COMPARATOR</b><span>Rank + explain</span></div></div></section>
      <section className="history"><div className="result-head"><div><span className="eyebrow">SEARCH HISTORY</span><h2>Recent requests</h2></div></div>{history.length===0?<p className="muted">Your searches will appear here.</p>:history.slice(0,5).map(h=><button className="history-row" key={h.id} onClick={()=>{setQuery(h.query);setData(h.result)}}><span>{h.query}</span><small>{new Date(h.created_at).toLocaleString()}</small></button>)}</section>
    </main>
    <footer>Built as a focused full-stack MVP · React + Express + SQLite + Gemini + web search</footer>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
