# ShopPilot AI — AI Shopping Agent

A focused full-stack MVP for the coding task: a user enters a natural-language shopping request; the agent parses requirements, searches public web results, extracts products/specifications, compares them and stores the result in SQLite.

## Stack
- React + Vite frontend
- Express backend
- SQLite (`better-sqlite3`) for search history/results
- Gemini 2.5 Flash for requirement parsing, product extraction and comparison
- DuckDuckGo HTML public web search for discovery

## Run in 2 minutes
1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env` and set `GEMINI_API_KEY`.
4. `npm run dev`
5. Open `http://localhost:5173`

If no Gemini key is configured, the app still starts but returns a helpful health status; the full extraction/comparison workflow needs an LLM key.

## Agent workflow
`User request → requirement parser → web search tool → product extraction tool → comparison/ranking tool → SQLite persistence → UI`

## API
- `GET /api/health`
- `GET /api/history`
- `POST /api/search` body `{ "query": "..." }`

## Demo request
`Find the best laptop for AI development under ₹70,000`

## Design choice
The UI is intentionally minimal because the task says to prioritize functionality and the agentic workflow over visual polish.
