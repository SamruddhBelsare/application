require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const cheerio = require('cheerio');
const { GoogleGenAI } = require('@google/genai');

const app = express();
const PORT = process.env.PORT || 3001;
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const db = new Database('shopping-agent.db');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS searches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query TEXT NOT NULL,
  result_json TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);

const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

function money(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

async function searchWeb(query) {
  const url = 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(query);
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 AI-Shopping-Agent/1.0' } });
  if (!res.ok) throw new Error('Web search failed');
  const html = await res.text();
  const $ = cheerio.load(html);
  const results = [];
  $('.result').each((_, el) => {
    const title = $(el).find('.result__title').text().trim();
    const href = $(el).find('.result__a').attr('href');
    const snippet = $(el).find('.result__snippet').text().trim();
    if (title && href) results.push({ title, url: href, snippet });
  });
  return results.slice(0, 12);
}

async function llmJson(prompt) {
  if (!ai) return null;
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: { responseMimeType: 'application/json', temperature: 0.2 }
  });
  const text = response.text || '{}';
  try { return JSON.parse(text); } catch { return null; }
}

async function parseRequirements(query) {
  const fallback = { category: query.includes('laptop') ? 'laptop' : 'product', budget: null, useCase: query, mustHave: [], niceToHave: [] };
  const data = await llmJson(`Extract shopping requirements from this request. Return JSON only with keys category, budget(number or null), currency, useCase, mustHave(array), niceToHave(array), location. Request: ${query}`);
  return data || fallback;
}

async function extractProducts(requirements, searchResults) {
  if (!searchResults.length) return [];
  const prompt = `You are a product extraction tool. From the web search results below, extract up to 8 real purchasable products relevant to the user's request. Do not invent products, prices, specs or links. If a field is unknown use null. Return JSON array only. Each item: {name, brand, price, currency, url, source, specs:{processor,ram,storage,gpu,display,battery}, summary}.\nREQUEST: ${JSON.stringify(requirements)}\nRESULTS:\n${JSON.stringify(searchResults)}`;
  const data = await llmJson(prompt);
  if (Array.isArray(data)) return data.filter(x => x && x.name && x.url);
  return searchResults.slice(0, 6).map(r => ({ name: r.title, brand: null, price: null, currency: 'INR', url: r.url, source: new URL(r.url).hostname, specs: {}, summary: r.snippet }));
}

async function compareProducts(requirements, products) {
  if (!products.length) return { recommendations: [], explanation: 'No products found.' };
  const prompt = `Act as a strict shopping comparison engine. Rank these products for the request. Prefer requirement fit, then value, then price. Never invent missing specs. Return JSON: {recommendations:[{name, score(0-100), reason, price, url}], winner, caveats}.\nREQUEST:${JSON.stringify(requirements)}\nPRODUCTS:${JSON.stringify(products)}`;
  const data = await llmJson(prompt);
  if (data?.recommendations) return data;
  return {
    recommendations: products.map((p, i) => ({ name: p.name, score: Math.max(60, 90 - i * 5), reason: p.summary || 'Relevant result', price: p.price, url: p.url })),
    winner: products[0]?.name,
    caveats: 'Some prices/specifications may need verification on the source page.'
  };
}

async function runAgent(query) {
  const requirements = await parseRequirements(query);
  const q = `${requirements.category || ''} ${requirements.useCase || query} ${requirements.budget ? 'under ' + requirements.budget : ''} India price specs buy`;
  const searchResults = await searchWeb(q);
  const products = await extractProducts(requirements, searchResults);
  const comparison = await compareProducts(requirements, products);
  return { query, requirements, products, comparison, searchedAt: new Date().toISOString() };
}

app.get('/api/health', (_, res) => res.json({ ok: true, llm: !!ai, message: ai ? 'Gemini connected' : 'Set GEMINI_API_KEY' }));
app.get('/api/history', (_, res) => {
  const rows = db.prepare('SELECT id, query, result_json, created_at FROM searches ORDER BY id DESC LIMIT 20').all();
  res.json(rows.map(r => ({ ...r, result: JSON.parse(r.result_json) })));
});
app.post('/api/search', async (req, res) => {
  try {
    const query = String(req.body.query || '').trim();
    if (!query) return res.status(400).json({ error: 'Query is required' });
    const result = await runAgent(query);
    db.prepare('INSERT INTO searches(query,result_json) VALUES(?,?)').run(query, JSON.stringify(result));
    res.json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || 'Agent failed' });
  }
});

app.listen(PORT, () => console.log(`AI Shopping Agent API running on http://localhost:${PORT}`));
